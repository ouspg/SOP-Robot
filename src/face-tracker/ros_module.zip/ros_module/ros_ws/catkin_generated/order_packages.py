# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = "/home/niko/catkin_ws/src"
whitelisted_packages = "".split(';') if "" != "" else []
blacklisted_packages = "".split(';') if "" != "" else []
underlay_workspaces = "/home/niko/catkin_ws/devel;/home/niko/SOP-Robot/devel;/opt/ros/melodic".split(';') if "/home/niko/catkin_ws/devel;/home/niko/SOP-Robot/devel;/opt/ros/melodic" != "" else []
